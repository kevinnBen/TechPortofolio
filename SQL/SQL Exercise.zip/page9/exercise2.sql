-- dapatkan id dan nama pengguna yang membeli "sandal"
select users.id, users.name
from users
join sales_records on users.id = sales_records.user_id
where item_id = (
  select id
  from items
  where name = "sandal"
)
group by users.id;