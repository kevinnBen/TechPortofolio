-- dapatkan data total penjualan untuk gender pria, wanita, dan netral
select gender, sum(price) as "total penjualan"
from items
join sales_records on items.id = sales_records.item_id
group by items.gender;