-- dapatkan semua barang dengan total penjualan yang lebih besar dari "hoodie abu-abu"
select items.id, items.name, sum(price) as "total penjualan"
from items
join sales_records on items.id = sales_records.item_id
group by items.id
having sum(price) > 
(
  select sum(price)
  from items
  join sales_records on items.id = sales_records.item_id
  where items.name = "hoodie abu-abu"
);
