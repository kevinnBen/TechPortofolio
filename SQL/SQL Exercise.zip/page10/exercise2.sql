-- dapatkan data untuk 5 produk dengan penjualan tertinggi 

select items.id, items.name, count(*) * items.price as "total penjualan"
from items
join sales_records on items.id = sales_records.item_id
group by items.id
order by count(*) * items.price desc
limit 5;