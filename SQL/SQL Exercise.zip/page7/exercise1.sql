-- dapatkan nama dan jumlah penjualan unit untuk 5 barang dengan penjualan tertinggi
select items.id, items.name, count(*)
from items
join sales_records on items.id = sales_records.item_id
group by items.id
order by count(*) desc
limit 5;